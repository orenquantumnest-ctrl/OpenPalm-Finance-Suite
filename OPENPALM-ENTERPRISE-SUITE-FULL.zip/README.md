
OPENPALM ENTERPRISE SUITE

Deployment:
Upload all contents into cPanel public_html directory.

Routes:
- /ev-loans/
- /openpalm-admin/
- /studio/

Responsive:
- Mobile
- Tablet
- Desktop
