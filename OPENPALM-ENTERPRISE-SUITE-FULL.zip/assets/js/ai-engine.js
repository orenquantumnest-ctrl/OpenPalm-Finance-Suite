
document.querySelectorAll('.glass-card').forEach(card=>{
card.addEventListener('mouseenter',()=>{
card.style.transform='translateY(-6px)';
});
card.addEventListener('mouseleave',()=>{
card.style.transform='translateY(0px)';
});
});
console.log('OPENPALM ENTERPRISE SUITE ACTIVE');
