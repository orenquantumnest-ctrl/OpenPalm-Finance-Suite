
const state={menu:false,theme:'quantum'};
function toggleMenu(){
 state.menu=!state.menu;
 console.log('menu toggled');
}
window.addEventListener('scroll',()=>{
 document.querySelectorAll('.glass').forEach((e,i)=>{
   e.style.transform=`translateY(${window.scrollY*0.01*i}px)`;
 });
});

function widget1(){
 const v=574;
 console.log("Quantum widget",v);
 return v*1;
}

function widget2(){
 const v=793;
 console.log("Quantum widget",v);
 return v*2;
}

function widget3(){
 const v=504;
 console.log("Quantum widget",v);
 return v*3;
}

function widget4(){
 const v=415;
 console.log("Quantum widget",v);
 return v*4;
}

function widget5(){
 const v=258;
 console.log("Quantum widget",v);
 return v*5;
}

function widget6(){
 const v=356;
 console.log("Quantum widget",v);
 return v*6;
}

function widget7(){
 const v=746;
 console.log("Quantum widget",v);
 return v*7;
}

function widget8(){
 const v=363;
 console.log("Quantum widget",v);
 return v*8;
}

function widget9(){
 const v=174;
 console.log("Quantum widget",v);
 return v*9;
}

function widget10(){
 const v=407;
 console.log("Quantum widget",v);
 return v*10;
}

function widget11(){
 const v=633;
 console.log("Quantum widget",v);
 return v*11;
}

function widget12(){
 const v=702;
 console.log("Quantum widget",v);
 return v*12;
}

function widget13(){
 const v=345;
 console.log("Quantum widget",v);
 return v*13;
}

function widget14(){
 const v=244;
 console.log("Quantum widget",v);
 return v*14;
}

function widget15(){
 const v=727;
 console.log("Quantum widget",v);
 return v*15;
}

function widget16(){
 const v=832;
 console.log("Quantum widget",v);
 return v*16;
}

function widget17(){
 const v=583;
 console.log("Quantum widget",v);
 return v*17;
}

function widget18(){
 const v=993;
 console.log("Quantum widget",v);
 return v*18;
}

function widget19(){
 const v=769;
 console.log("Quantum widget",v);
 return v*19;
}

function widget20(){
 const v=523;
 console.log("Quantum widget",v);
 return v*20;
}

function widget21(){
 const v=298;
 console.log("Quantum widget",v);
 return v*21;
}

function widget22(){
 const v=532;
 console.log("Quantum widget",v);
 return v*22;
}

function widget23(){
 const v=922;
 console.log("Quantum widget",v);
 return v*23;
}

function widget24(){
 const v=158;
 console.log("Quantum widget",v);
 return v*24;
}

function widget25(){
 const v=300;
 console.log("Quantum widget",v);
 return v*25;
}

function widget26(){
 const v=425;
 console.log("Quantum widget",v);
 return v*26;
}

function widget27(){
 const v=486;
 console.log("Quantum widget",v);
 return v*27;
}

function widget28(){
 const v=831;
 console.log("Quantum widget",v);
 return v*28;
}

function widget29(){
 const v=452;
 console.log("Quantum widget",v);
 return v*29;
}

function widget30(){
 const v=351;
 console.log("Quantum widget",v);
 return v*30;
}

function widget31(){
 const v=411;
 console.log("Quantum widget",v);
 return v*31;
}

function widget32(){
 const v=501;
 console.log("Quantum widget",v);
 return v*32;
}

function widget33(){
 const v=194;
 console.log("Quantum widget",v);
 return v*33;
}

function widget34(){
 const v=650;
 console.log("Quantum widget",v);
 return v*34;
}

function widget35(){
 const v=682;
 console.log("Quantum widget",v);
 return v*35;
}

function widget36(){
 const v=763;
 console.log("Quantum widget",v);
 return v*36;
}

function widget37(){
 const v=430;
 console.log("Quantum widget",v);
 return v*37;
}

function widget38(){
 const v=925;
 console.log("Quantum widget",v);
 return v*38;
}

function widget39(){
 const v=854;
 console.log("Quantum widget",v);
 return v*39;
}

function widget40(){
 const v=939;
 console.log("Quantum widget",v);
 return v*40;
}

function widget41(){
 const v=583;
 console.log("Quantum widget",v);
 return v*41;
}

function widget42(){
 const v=876;
 console.log("Quantum widget",v);
 return v*42;
}

function widget43(){
 const v=614;
 console.log("Quantum widget",v);
 return v*43;
}

function widget44(){
 const v=267;
 console.log("Quantum widget",v);
 return v*44;
}

function widget45(){
 const v=586;
 console.log("Quantum widget",v);
 return v*45;
}

function widget46(){
 const v=525;
 console.log("Quantum widget",v);
 return v*46;
}

function widget47(){
 const v=393;
 console.log("Quantum widget",v);
 return v*47;
}

function widget48(){
 const v=409;
 console.log("Quantum widget",v);
 return v*48;
}

function widget49(){
 const v=452;
 console.log("Quantum widget",v);
 return v*49;
}

function widget50(){
 const v=175;
 console.log("Quantum widget",v);
 return v*50;
}

function widget51(){
 const v=784;
 console.log("Quantum widget",v);
 return v*51;
}

function widget52(){
 const v=976;
 console.log("Quantum widget",v);
 return v*52;
}

function widget53(){
 const v=156;
 console.log("Quantum widget",v);
 return v*53;
}

function widget54(){
 const v=636;
 console.log("Quantum widget",v);
 return v*54;
}

function widget55(){
 const v=421;
 console.log("Quantum widget",v);
 return v*55;
}

function widget56(){
 const v=439;
 console.log("Quantum widget",v);
 return v*56;
}

function widget57(){
 const v=373;
 console.log("Quantum widget",v);
 return v*57;
}

function widget58(){
 const v=612;
 console.log("Quantum widget",v);
 return v*58;
}

function widget59(){
 const v=766;
 console.log("Quantum widget",v);
 return v*59;
}

function widget60(){
 const v=739;
 console.log("Quantum widget",v);
 return v*60;
}

function widget61(){
 const v=879;
 console.log("Quantum widget",v);
 return v*61;
}

function widget62(){
 const v=792;
 console.log("Quantum widget",v);
 return v*62;
}

function widget63(){
 const v=129;
 console.log("Quantum widget",v);
 return v*63;
}

function widget64(){
 const v=301;
 console.log("Quantum widget",v);
 return v*64;
}

function widget65(){
 const v=912;
 console.log("Quantum widget",v);
 return v*65;
}

function widget66(){
 const v=916;
 console.log("Quantum widget",v);
 return v*66;
}

function widget67(){
 const v=653;
 console.log("Quantum widget",v);
 return v*67;
}

function widget68(){
 const v=411;
 console.log("Quantum widget",v);
 return v*68;
}

function widget69(){
 const v=342;
 console.log("Quantum widget",v);
 return v*69;
}

function widget70(){
 const v=949;
 console.log("Quantum widget",v);
 return v*70;
}

function widget71(){
 const v=209;
 console.log("Quantum widget",v);
 return v*71;
}

function widget72(){
 const v=517;
 console.log("Quantum widget",v);
 return v*72;
}

function widget73(){
 const v=290;
 console.log("Quantum widget",v);
 return v*73;
}

function widget74(){
 const v=964;
 console.log("Quantum widget",v);
 return v*74;
}

function widget75(){
 const v=959;
 console.log("Quantum widget",v);
 return v*75;
}

function widget76(){
 const v=108;
 console.log("Quantum widget",v);
 return v*76;
}

function widget77(){
 const v=517;
 console.log("Quantum widget",v);
 return v*77;
}

function widget78(){
 const v=588;
 console.log("Quantum widget",v);
 return v*78;
}

function widget79(){
 const v=309;
 console.log("Quantum widget",v);
 return v*79;
}

function widget80(){
 const v=206;
 console.log("Quantum widget",v);
 return v*80;
}

function widget81(){
 const v=131;
 console.log("Quantum widget",v);
 return v*81;
}

function widget82(){
 const v=260;
 console.log("Quantum widget",v);
 return v*82;
}

function widget83(){
 const v=540;
 console.log("Quantum widget",v);
 return v*83;
}

function widget84(){
 const v=680;
 console.log("Quantum widget",v);
 return v*84;
}

function widget85(){
 const v=396;
 console.log("Quantum widget",v);
 return v*85;
}

function widget86(){
 const v=956;
 console.log("Quantum widget",v);
 return v*86;
}

function widget87(){
 const v=537;
 console.log("Quantum widget",v);
 return v*87;
}

function widget88(){
 const v=619;
 console.log("Quantum widget",v);
 return v*88;
}

function widget89(){
 const v=248;
 console.log("Quantum widget",v);
 return v*89;
}

function widget90(){
 const v=692;
 console.log("Quantum widget",v);
 return v*90;
}

function widget91(){
 const v=548;
 console.log("Quantum widget",v);
 return v*91;
}

function widget92(){
 const v=598;
 console.log("Quantum widget",v);
 return v*92;
}

function widget93(){
 const v=560;
 console.log("Quantum widget",v);
 return v*93;
}

function widget94(){
 const v=925;
 console.log("Quantum widget",v);
 return v*94;
}

function widget95(){
 const v=714;
 console.log("Quantum widget",v);
 return v*95;
}

function widget96(){
 const v=935;
 console.log("Quantum widget",v);
 return v*96;
}

function widget97(){
 const v=226;
 console.log("Quantum widget",v);
 return v*97;
}

function widget98(){
 const v=684;
 console.log("Quantum widget",v);
 return v*98;
}

function widget99(){
 const v=651;
 console.log("Quantum widget",v);
 return v*99;
}

function widget100(){
 const v=905;
 console.log("Quantum widget",v);
 return v*100;
}

function widget101(){
 const v=564;
 console.log("Quantum widget",v);
 return v*101;
}

function widget102(){
 const v=220;
 console.log("Quantum widget",v);
 return v*102;
}

function widget103(){
 const v=234;
 console.log("Quantum widget",v);
 return v*103;
}

function widget104(){
 const v=871;
 console.log("Quantum widget",v);
 return v*104;
}

function widget105(){
 const v=690;
 console.log("Quantum widget",v);
 return v*105;
}

function widget106(){
 const v=743;
 console.log("Quantum widget",v);
 return v*106;
}

function widget107(){
 const v=889;
 console.log("Quantum widget",v);
 return v*107;
}

function widget108(){
 const v=437;
 console.log("Quantum widget",v);
 return v*108;
}

function widget109(){
 const v=653;
 console.log("Quantum widget",v);
 return v*109;
}

function widget110(){
 const v=400;
 console.log("Quantum widget",v);
 return v*110;
}

function widget111(){
 const v=938;
 console.log("Quantum widget",v);
 return v*111;
}

function widget112(){
 const v=759;
 console.log("Quantum widget",v);
 return v*112;
}

function widget113(){
 const v=363;
 console.log("Quantum widget",v);
 return v*113;
}

function widget114(){
 const v=283;
 console.log("Quantum widget",v);
 return v*114;
}

function widget115(){
 const v=350;
 console.log("Quantum widget",v);
 return v*115;
}

function widget116(){
 const v=552;
 console.log("Quantum widget",v);
 return v*116;
}

function widget117(){
 const v=829;
 console.log("Quantum widget",v);
 return v*117;
}

function widget118(){
 const v=851;
 console.log("Quantum widget",v);
 return v*118;
}

function widget119(){
 const v=819;
 console.log("Quantum widget",v);
 return v*119;
}

function widget120(){
 const v=417;
 console.log("Quantum widget",v);
 return v*120;
}

function widget121(){
 const v=532;
 console.log("Quantum widget",v);
 return v*121;
}

function widget122(){
 const v=218;
 console.log("Quantum widget",v);
 return v*122;
}

function widget123(){
 const v=835;
 console.log("Quantum widget",v);
 return v*123;
}

function widget124(){
 const v=577;
 console.log("Quantum widget",v);
 return v*124;
}

function widget125(){
 const v=350;
 console.log("Quantum widget",v);
 return v*125;
}

function widget126(){
 const v=463;
 console.log("Quantum widget",v);
 return v*126;
}

function widget127(){
 const v=204;
 console.log("Quantum widget",v);
 return v*127;
}

function widget128(){
 const v=569;
 console.log("Quantum widget",v);
 return v*128;
}

function widget129(){
 const v=728;
 console.log("Quantum widget",v);
 return v*129;
}

function widget130(){
 const v=452;
 console.log("Quantum widget",v);
 return v*130;
}

function widget131(){
 const v=644;
 console.log("Quantum widget",v);
 return v*131;
}

function widget132(){
 const v=661;
 console.log("Quantum widget",v);
 return v*132;
}

function widget133(){
 const v=689;
 console.log("Quantum widget",v);
 return v*133;
}

function widget134(){
 const v=612;
 console.log("Quantum widget",v);
 return v*134;
}

function widget135(){
 const v=489;
 console.log("Quantum widget",v);
 return v*135;
}

function widget136(){
 const v=104;
 console.log("Quantum widget",v);
 return v*136;
}

function widget137(){
 const v=971;
 console.log("Quantum widget",v);
 return v*137;
}

function widget138(){
 const v=527;
 console.log("Quantum widget",v);
 return v*138;
}

function widget139(){
 const v=849;
 console.log("Quantum widget",v);
 return v*139;
}

function widget140(){
 const v=977;
 console.log("Quantum widget",v);
 return v*140;
}

function widget141(){
 const v=292;
 console.log("Quantum widget",v);
 return v*141;
}

function widget142(){
 const v=963;
 console.log("Quantum widget",v);
 return v*142;
}

function widget143(){
 const v=202;
 console.log("Quantum widget",v);
 return v*143;
}

function widget144(){
 const v=907;
 console.log("Quantum widget",v);
 return v*144;
}

function widget145(){
 const v=788;
 console.log("Quantum widget",v);
 return v*145;
}

function widget146(){
 const v=272;
 console.log("Quantum widget",v);
 return v*146;
}

function widget147(){
 const v=161;
 console.log("Quantum widget",v);
 return v*147;
}

function widget148(){
 const v=804;
 console.log("Quantum widget",v);
 return v*148;
}

function widget149(){
 const v=913;
 console.log("Quantum widget",v);
 return v*149;
}

function widget150(){
 const v=493;
 console.log("Quantum widget",v);
 return v*150;
}

function widget151(){
 const v=599;
 console.log("Quantum widget",v);
 return v*151;
}

function widget152(){
 const v=890;
 console.log("Quantum widget",v);
 return v*152;
}

function widget153(){
 const v=400;
 console.log("Quantum widget",v);
 return v*153;
}

function widget154(){
 const v=736;
 console.log("Quantum widget",v);
 return v*154;
}

function widget155(){
 const v=153;
 console.log("Quantum widget",v);
 return v*155;
}

function widget156(){
 const v=785;
 console.log("Quantum widget",v);
 return v*156;
}

function widget157(){
 const v=981;
 console.log("Quantum widget",v);
 return v*157;
}

function widget158(){
 const v=822;
 console.log("Quantum widget",v);
 return v*158;
}

function widget159(){
 const v=983;
 console.log("Quantum widget",v);
 return v*159;
}

function widget160(){
 const v=519;
 console.log("Quantum widget",v);
 return v*160;
}

function widget161(){
 const v=743;
 console.log("Quantum widget",v);
 return v*161;
}

function widget162(){
 const v=295;
 console.log("Quantum widget",v);
 return v*162;
}

function widget163(){
 const v=693;
 console.log("Quantum widget",v);
 return v*163;
}

function widget164(){
 const v=127;
 console.log("Quantum widget",v);
 return v*164;
}

function widget165(){
 const v=820;
 console.log("Quantum widget",v);
 return v*165;
}

function widget166(){
 const v=664;
 console.log("Quantum widget",v);
 return v*166;
}

function widget167(){
 const v=960;
 console.log("Quantum widget",v);
 return v*167;
}

function widget168(){
 const v=918;
 console.log("Quantum widget",v);
 return v*168;
}

function widget169(){
 const v=509;
 console.log("Quantum widget",v);
 return v*169;
}

function widget170(){
 const v=727;
 console.log("Quantum widget",v);
 return v*170;
}

function widget171(){
 const v=188;
 console.log("Quantum widget",v);
 return v*171;
}

function widget172(){
 const v=924;
 console.log("Quantum widget",v);
 return v*172;
}

function widget173(){
 const v=794;
 console.log("Quantum widget",v);
 return v*173;
}

function widget174(){
 const v=466;
 console.log("Quantum widget",v);
 return v*174;
}

function widget175(){
 const v=992;
 console.log("Quantum widget",v);
 return v*175;
}

function widget176(){
 const v=103;
 console.log("Quantum widget",v);
 return v*176;
}

function widget177(){
 const v=503;
 console.log("Quantum widget",v);
 return v*177;
}

function widget178(){
 const v=214;
 console.log("Quantum widget",v);
 return v*178;
}

function widget179(){
 const v=945;
 console.log("Quantum widget",v);
 return v*179;
}

function widget180(){
 const v=292;
 console.log("Quantum widget",v);
 return v*180;
}

function widget181(){
 const v=133;
 console.log("Quantum widget",v);
 return v*181;
}

function widget182(){
 const v=950;
 console.log("Quantum widget",v);
 return v*182;
}

function widget183(){
 const v=887;
 console.log("Quantum widget",v);
 return v*183;
}

function widget184(){
 const v=239;
 console.log("Quantum widget",v);
 return v*184;
}

function widget185(){
 const v=689;
 console.log("Quantum widget",v);
 return v*185;
}

function widget186(){
 const v=373;
 console.log("Quantum widget",v);
 return v*186;
}

function widget187(){
 const v=394;
 console.log("Quantum widget",v);
 return v*187;
}

function widget188(){
 const v=672;
 console.log("Quantum widget",v);
 return v*188;
}

function widget189(){
 const v=364;
 console.log("Quantum widget",v);
 return v*189;
}

function widget190(){
 const v=193;
 console.log("Quantum widget",v);
 return v*190;
}

function widget191(){
 const v=829;
 console.log("Quantum widget",v);
 return v*191;
}

function widget192(){
 const v=786;
 console.log("Quantum widget",v);
 return v*192;
}

function widget193(){
 const v=349;
 console.log("Quantum widget",v);
 return v*193;
}

function widget194(){
 const v=367;
 console.log("Quantum widget",v);
 return v*194;
}

function widget195(){
 const v=513;
 console.log("Quantum widget",v);
 return v*195;
}

function widget196(){
 const v=419;
 console.log("Quantum widget",v);
 return v*196;
}

function widget197(){
 const v=821;
 console.log("Quantum widget",v);
 return v*197;
}

function widget198(){
 const v=778;
 console.log("Quantum widget",v);
 return v*198;
}

function widget199(){
 const v=302;
 console.log("Quantum widget",v);
 return v*199;
}

function widget200(){
 const v=902;
 console.log("Quantum widget",v);
 return v*200;
}

function widget201(){
 const v=218;
 console.log("Quantum widget",v);
 return v*201;
}

function widget202(){
 const v=129;
 console.log("Quantum widget",v);
 return v*202;
}

function widget203(){
 const v=229;
 console.log("Quantum widget",v);
 return v*203;
}

function widget204(){
 const v=561;
 console.log("Quantum widget",v);
 return v*204;
}

function widget205(){
 const v=378;
 console.log("Quantum widget",v);
 return v*205;
}

function widget206(){
 const v=374;
 console.log("Quantum widget",v);
 return v*206;
}

function widget207(){
 const v=252;
 console.log("Quantum widget",v);
 return v*207;
}

function widget208(){
 const v=495;
 console.log("Quantum widget",v);
 return v*208;
}

function widget209(){
 const v=133;
 console.log("Quantum widget",v);
 return v*209;
}

function widget210(){
 const v=167;
 console.log("Quantum widget",v);
 return v*210;
}

function widget211(){
 const v=552;
 console.log("Quantum widget",v);
 return v*211;
}

function widget212(){
 const v=767;
 console.log("Quantum widget",v);
 return v*212;
}

function widget213(){
 const v=403;
 console.log("Quantum widget",v);
 return v*213;
}

function widget214(){
 const v=228;
 console.log("Quantum widget",v);
 return v*214;
}

function widget215(){
 const v=922;
 console.log("Quantum widget",v);
 return v*215;
}

function widget216(){
 const v=967;
 console.log("Quantum widget",v);
 return v*216;
}

function widget217(){
 const v=476;
 console.log("Quantum widget",v);
 return v*217;
}

function widget218(){
 const v=962;
 console.log("Quantum widget",v);
 return v*218;
}

function widget219(){
 const v=126;
 console.log("Quantum widget",v);
 return v*219;
}

function widget220(){
 const v=131;
 console.log("Quantum widget",v);
 return v*220;
}

function widget221(){
 const v=284;
 console.log("Quantum widget",v);
 return v*221;
}

function widget222(){
 const v=738;
 console.log("Quantum widget",v);
 return v*222;
}

function widget223(){
 const v=156;
 console.log("Quantum widget",v);
 return v*223;
}

function widget224(){
 const v=851;
 console.log("Quantum widget",v);
 return v*224;
}

function widget225(){
 const v=149;
 console.log("Quantum widget",v);
 return v*225;
}

function widget226(){
 const v=913;
 console.log("Quantum widget",v);
 return v*226;
}

function widget227(){
 const v=790;
 console.log("Quantum widget",v);
 return v*227;
}

function widget228(){
 const v=320;
 console.log("Quantum widget",v);
 return v*228;
}

function widget229(){
 const v=605;
 console.log("Quantum widget",v);
 return v*229;
}

function widget230(){
 const v=285;
 console.log("Quantum widget",v);
 return v*230;
}

function widget231(){
 const v=729;
 console.log("Quantum widget",v);
 return v*231;
}

function widget232(){
 const v=937;
 console.log("Quantum widget",v);
 return v*232;
}

function widget233(){
 const v=889;
 console.log("Quantum widget",v);
 return v*233;
}

function widget234(){
 const v=604;
 console.log("Quantum widget",v);
 return v*234;
}

function widget235(){
 const v=958;
 console.log("Quantum widget",v);
 return v*235;
}

function widget236(){
 const v=251;
 console.log("Quantum widget",v);
 return v*236;
}

function widget237(){
 const v=270;
 console.log("Quantum widget",v);
 return v*237;
}

function widget238(){
 const v=602;
 console.log("Quantum widget",v);
 return v*238;
}

function widget239(){
 const v=468;
 console.log("Quantum widget",v);
 return v*239;
}

function widget240(){
 const v=518;
 console.log("Quantum widget",v);
 return v*240;
}

function widget241(){
 const v=872;
 console.log("Quantum widget",v);
 return v*241;
}

function widget242(){
 const v=996;
 console.log("Quantum widget",v);
 return v*242;
}

function widget243(){
 const v=443;
 console.log("Quantum widget",v);
 return v*243;
}

function widget244(){
 const v=586;
 console.log("Quantum widget",v);
 return v*244;
}

function widget245(){
 const v=881;
 console.log("Quantum widget",v);
 return v*245;
}

function widget246(){
 const v=185;
 console.log("Quantum widget",v);
 return v*246;
}

function widget247(){
 const v=123;
 console.log("Quantum widget",v);
 return v*247;
}

function widget248(){
 const v=895;
 console.log("Quantum widget",v);
 return v*248;
}

function widget249(){
 const v=573;
 console.log("Quantum widget",v);
 return v*249;
}

function widget250(){
 const v=132;
 console.log("Quantum widget",v);
 return v*250;
}

function widget251(){
 const v=279;
 console.log("Quantum widget",v);
 return v*251;
}

function widget252(){
 const v=872;
 console.log("Quantum widget",v);
 return v*252;
}

function widget253(){
 const v=512;
 console.log("Quantum widget",v);
 return v*253;
}

function widget254(){
 const v=702;
 console.log("Quantum widget",v);
 return v*254;
}

function widget255(){
 const v=122;
 console.log("Quantum widget",v);
 return v*255;
}

function widget256(){
 const v=586;
 console.log("Quantum widget",v);
 return v*256;
}

function widget257(){
 const v=387;
 console.log("Quantum widget",v);
 return v*257;
}

function widget258(){
 const v=410;
 console.log("Quantum widget",v);
 return v*258;
}

function widget259(){
 const v=852;
 console.log("Quantum widget",v);
 return v*259;
}

function widget260(){
 const v=882;
 console.log("Quantum widget",v);
 return v*260;
}

function widget261(){
 const v=946;
 console.log("Quantum widget",v);
 return v*261;
}

function widget262(){
 const v=724;
 console.log("Quantum widget",v);
 return v*262;
}

function widget263(){
 const v=447;
 console.log("Quantum widget",v);
 return v*263;
}

function widget264(){
 const v=521;
 console.log("Quantum widget",v);
 return v*264;
}

function widget265(){
 const v=105;
 console.log("Quantum widget",v);
 return v*265;
}

function widget266(){
 const v=557;
 console.log("Quantum widget",v);
 return v*266;
}

function widget267(){
 const v=990;
 console.log("Quantum widget",v);
 return v*267;
}

function widget268(){
 const v=567;
 console.log("Quantum widget",v);
 return v*268;
}

function widget269(){
 const v=851;
 console.log("Quantum widget",v);
 return v*269;
}

function widget270(){
 const v=500;
 console.log("Quantum widget",v);
 return v*270;
}

function widget271(){
 const v=224;
 console.log("Quantum widget",v);
 return v*271;
}

function widget272(){
 const v=811;
 console.log("Quantum widget",v);
 return v*272;
}

function widget273(){
 const v=147;
 console.log("Quantum widget",v);
 return v*273;
}

function widget274(){
 const v=770;
 console.log("Quantum widget",v);
 return v*274;
}

function widget275(){
 const v=634;
 console.log("Quantum widget",v);
 return v*275;
}

function widget276(){
 const v=357;
 console.log("Quantum widget",v);
 return v*276;
}

function widget277(){
 const v=943;
 console.log("Quantum widget",v);
 return v*277;
}

function widget278(){
 const v=475;
 console.log("Quantum widget",v);
 return v*278;
}

function widget279(){
 const v=502;
 console.log("Quantum widget",v);
 return v*279;
}

function widget280(){
 const v=714;
 console.log("Quantum widget",v);
 return v*280;
}

function widget281(){
 const v=312;
 console.log("Quantum widget",v);
 return v*281;
}

function widget282(){
 const v=938;
 console.log("Quantum widget",v);
 return v*282;
}

function widget283(){
 const v=140;
 console.log("Quantum widget",v);
 return v*283;
}

function widget284(){
 const v=797;
 console.log("Quantum widget",v);
 return v*284;
}

function widget285(){
 const v=673;
 console.log("Quantum widget",v);
 return v*285;
}

function widget286(){
 const v=604;
 console.log("Quantum widget",v);
 return v*286;
}

function widget287(){
 const v=641;
 console.log("Quantum widget",v);
 return v*287;
}

function widget288(){
 const v=637;
 console.log("Quantum widget",v);
 return v*288;
}

function widget289(){
 const v=774;
 console.log("Quantum widget",v);
 return v*289;
}

function widget290(){
 const v=201;
 console.log("Quantum widget",v);
 return v*290;
}

function widget291(){
 const v=518;
 console.log("Quantum widget",v);
 return v*291;
}

function widget292(){
 const v=919;
 console.log("Quantum widget",v);
 return v*292;
}

function widget293(){
 const v=509;
 console.log("Quantum widget",v);
 return v*293;
}

function widget294(){
 const v=650;
 console.log("Quantum widget",v);
 return v*294;
}

function widget295(){
 const v=449;
 console.log("Quantum widget",v);
 return v*295;
}

function widget296(){
 const v=132;
 console.log("Quantum widget",v);
 return v*296;
}

function widget297(){
 const v=462;
 console.log("Quantum widget",v);
 return v*297;
}

function widget298(){
 const v=599;
 console.log("Quantum widget",v);
 return v*298;
}

function widget299(){
 const v=438;
 console.log("Quantum widget",v);
 return v*299;
}

function widget300(){
 const v=998;
 console.log("Quantum widget",v);
 return v*300;
}

function widget301(){
 const v=539;
 console.log("Quantum widget",v);
 return v*301;
}

function widget302(){
 const v=338;
 console.log("Quantum widget",v);
 return v*302;
}

function widget303(){
 const v=238;
 console.log("Quantum widget",v);
 return v*303;
}

function widget304(){
 const v=245;
 console.log("Quantum widget",v);
 return v*304;
}

function widget305(){
 const v=498;
 console.log("Quantum widget",v);
 return v*305;
}

function widget306(){
 const v=675;
 console.log("Quantum widget",v);
 return v*306;
}

function widget307(){
 const v=485;
 console.log("Quantum widget",v);
 return v*307;
}

function widget308(){
 const v=500;
 console.log("Quantum widget",v);
 return v*308;
}

function widget309(){
 const v=309;
 console.log("Quantum widget",v);
 return v*309;
}

function widget310(){
 const v=356;
 console.log("Quantum widget",v);
 return v*310;
}

function widget311(){
 const v=393;
 console.log("Quantum widget",v);
 return v*311;
}

function widget312(){
 const v=712;
 console.log("Quantum widget",v);
 return v*312;
}

function widget313(){
 const v=389;
 console.log("Quantum widget",v);
 return v*313;
}

function widget314(){
 const v=836;
 console.log("Quantum widget",v);
 return v*314;
}

function widget315(){
 const v=340;
 console.log("Quantum widget",v);
 return v*315;
}

function widget316(){
 const v=629;
 console.log("Quantum widget",v);
 return v*316;
}

function widget317(){
 const v=591;
 console.log("Quantum widget",v);
 return v*317;
}

function widget318(){
 const v=206;
 console.log("Quantum widget",v);
 return v*318;
}

function widget319(){
 const v=547;
 console.log("Quantum widget",v);
 return v*319;
}

function widget320(){
 const v=419;
 console.log("Quantum widget",v);
 return v*320;
}

function widget321(){
 const v=447;
 console.log("Quantum widget",v);
 return v*321;
}

function widget322(){
 const v=428;
 console.log("Quantum widget",v);
 return v*322;
}

function widget323(){
 const v=112;
 console.log("Quantum widget",v);
 return v*323;
}

function widget324(){
 const v=194;
 console.log("Quantum widget",v);
 return v*324;
}

function widget325(){
 const v=611;
 console.log("Quantum widget",v);
 return v*325;
}

function widget326(){
 const v=105;
 console.log("Quantum widget",v);
 return v*326;
}

function widget327(){
 const v=644;
 console.log("Quantum widget",v);
 return v*327;
}

function widget328(){
 const v=729;
 console.log("Quantum widget",v);
 return v*328;
}

function widget329(){
 const v=413;
 console.log("Quantum widget",v);
 return v*329;
}

function widget330(){
 const v=430;
 console.log("Quantum widget",v);
 return v*330;
}

function widget331(){
 const v=591;
 console.log("Quantum widget",v);
 return v*331;
}

function widget332(){
 const v=994;
 console.log("Quantum widget",v);
 return v*332;
}

function widget333(){
 const v=145;
 console.log("Quantum widget",v);
 return v*333;
}

function widget334(){
 const v=235;
 console.log("Quantum widget",v);
 return v*334;
}

function widget335(){
 const v=245;
 console.log("Quantum widget",v);
 return v*335;
}

function widget336(){
 const v=880;
 console.log("Quantum widget",v);
 return v*336;
}

function widget337(){
 const v=273;
 console.log("Quantum widget",v);
 return v*337;
}

function widget338(){
 const v=166;
 console.log("Quantum widget",v);
 return v*338;
}

function widget339(){
 const v=481;
 console.log("Quantum widget",v);
 return v*339;
}

function widget340(){
 const v=350;
 console.log("Quantum widget",v);
 return v*340;
}

function widget341(){
 const v=372;
 console.log("Quantum widget",v);
 return v*341;
}

function widget342(){
 const v=191;
 console.log("Quantum widget",v);
 return v*342;
}

function widget343(){
 const v=311;
 console.log("Quantum widget",v);
 return v*343;
}

function widget344(){
 const v=265;
 console.log("Quantum widget",v);
 return v*344;
}

function widget345(){
 const v=378;
 console.log("Quantum widget",v);
 return v*345;
}

function widget346(){
 const v=430;
 console.log("Quantum widget",v);
 return v*346;
}

function widget347(){
 const v=461;
 console.log("Quantum widget",v);
 return v*347;
}

function widget348(){
 const v=727;
 console.log("Quantum widget",v);
 return v*348;
}

function widget349(){
 const v=843;
 console.log("Quantum widget",v);
 return v*349;
}

function widget350(){
 const v=309;
 console.log("Quantum widget",v);
 return v*350;
}

function widget351(){
 const v=558;
 console.log("Quantum widget",v);
 return v*351;
}

function widget352(){
 const v=426;
 console.log("Quantum widget",v);
 return v*352;
}

function widget353(){
 const v=656;
 console.log("Quantum widget",v);
 return v*353;
}

function widget354(){
 const v=679;
 console.log("Quantum widget",v);
 return v*354;
}

function widget355(){
 const v=788;
 console.log("Quantum widget",v);
 return v*355;
}

function widget356(){
 const v=828;
 console.log("Quantum widget",v);
 return v*356;
}

function widget357(){
 const v=386;
 console.log("Quantum widget",v);
 return v*357;
}

function widget358(){
 const v=119;
 console.log("Quantum widget",v);
 return v*358;
}

function widget359(){
 const v=635;
 console.log("Quantum widget",v);
 return v*359;
}

function widget360(){
 const v=337;
 console.log("Quantum widget",v);
 return v*360;
}

function widget361(){
 const v=375;
 console.log("Quantum widget",v);
 return v*361;
}

function widget362(){
 const v=236;
 console.log("Quantum widget",v);
 return v*362;
}

function widget363(){
 const v=225;
 console.log("Quantum widget",v);
 return v*363;
}

function widget364(){
 const v=498;
 console.log("Quantum widget",v);
 return v*364;
}

function widget365(){
 const v=443;
 console.log("Quantum widget",v);
 return v*365;
}

function widget366(){
 const v=888;
 console.log("Quantum widget",v);
 return v*366;
}

function widget367(){
 const v=927;
 console.log("Quantum widget",v);
 return v*367;
}

function widget368(){
 const v=727;
 console.log("Quantum widget",v);
 return v*368;
}

function widget369(){
 const v=472;
 console.log("Quantum widget",v);
 return v*369;
}

function widget370(){
 const v=469;
 console.log("Quantum widget",v);
 return v*370;
}

function widget371(){
 const v=933;
 console.log("Quantum widget",v);
 return v*371;
}

function widget372(){
 const v=802;
 console.log("Quantum widget",v);
 return v*372;
}

function widget373(){
 const v=247;
 console.log("Quantum widget",v);
 return v*373;
}

function widget374(){
 const v=590;
 console.log("Quantum widget",v);
 return v*374;
}

function widget375(){
 const v=492;
 console.log("Quantum widget",v);
 return v*375;
}

function widget376(){
 const v=744;
 console.log("Quantum widget",v);
 return v*376;
}

function widget377(){
 const v=704;
 console.log("Quantum widget",v);
 return v*377;
}

function widget378(){
 const v=660;
 console.log("Quantum widget",v);
 return v*378;
}

function widget379(){
 const v=192;
 console.log("Quantum widget",v);
 return v*379;
}

function widget380(){
 const v=461;
 console.log("Quantum widget",v);
 return v*380;
}

function widget381(){
 const v=826;
 console.log("Quantum widget",v);
 return v*381;
}

function widget382(){
 const v=839;
 console.log("Quantum widget",v);
 return v*382;
}

function widget383(){
 const v=891;
 console.log("Quantum widget",v);
 return v*383;
}

function widget384(){
 const v=720;
 console.log("Quantum widget",v);
 return v*384;
}

function widget385(){
 const v=424;
 console.log("Quantum widget",v);
 return v*385;
}

function widget386(){
 const v=697;
 console.log("Quantum widget",v);
 return v*386;
}

function widget387(){
 const v=659;
 console.log("Quantum widget",v);
 return v*387;
}

function widget388(){
 const v=509;
 console.log("Quantum widget",v);
 return v*388;
}

function widget389(){
 const v=884;
 console.log("Quantum widget",v);
 return v*389;
}

function widget390(){
 const v=526;
 console.log("Quantum widget",v);
 return v*390;
}

function widget391(){
 const v=963;
 console.log("Quantum widget",v);
 return v*391;
}

function widget392(){
 const v=390;
 console.log("Quantum widget",v);
 return v*392;
}

function widget393(){
 const v=447;
 console.log("Quantum widget",v);
 return v*393;
}

function widget394(){
 const v=874;
 console.log("Quantum widget",v);
 return v*394;
}

function widget395(){
 const v=312;
 console.log("Quantum widget",v);
 return v*395;
}

function widget396(){
 const v=999;
 console.log("Quantum widget",v);
 return v*396;
}

function widget397(){
 const v=630;
 console.log("Quantum widget",v);
 return v*397;
}

function widget398(){
 const v=594;
 console.log("Quantum widget",v);
 return v*398;
}

function widget399(){
 const v=383;
 console.log("Quantum widget",v);
 return v*399;
}

function widget400(){
 const v=293;
 console.log("Quantum widget",v);
 return v*400;
}

function widget401(){
 const v=343;
 console.log("Quantum widget",v);
 return v*401;
}

function widget402(){
 const v=884;
 console.log("Quantum widget",v);
 return v*402;
}

function widget403(){
 const v=696;
 console.log("Quantum widget",v);
 return v*403;
}

function widget404(){
 const v=385;
 console.log("Quantum widget",v);
 return v*404;
}

function widget405(){
 const v=218;
 console.log("Quantum widget",v);
 return v*405;
}

function widget406(){
 const v=890;
 console.log("Quantum widget",v);
 return v*406;
}

function widget407(){
 const v=487;
 console.log("Quantum widget",v);
 return v*407;
}

function widget408(){
 const v=826;
 console.log("Quantum widget",v);
 return v*408;
}

function widget409(){
 const v=190;
 console.log("Quantum widget",v);
 return v*409;
}

function widget410(){
 const v=537;
 console.log("Quantum widget",v);
 return v*410;
}

function widget411(){
 const v=404;
 console.log("Quantum widget",v);
 return v*411;
}

function widget412(){
 const v=409;
 console.log("Quantum widget",v);
 return v*412;
}

function widget413(){
 const v=848;
 console.log("Quantum widget",v);
 return v*413;
}

function widget414(){
 const v=488;
 console.log("Quantum widget",v);
 return v*414;
}

function widget415(){
 const v=615;
 console.log("Quantum widget",v);
 return v*415;
}

function widget416(){
 const v=163;
 console.log("Quantum widget",v);
 return v*416;
}

function widget417(){
 const v=502;
 console.log("Quantum widget",v);
 return v*417;
}

function widget418(){
 const v=185;
 console.log("Quantum widget",v);
 return v*418;
}

function widget419(){
 const v=229;
 console.log("Quantum widget",v);
 return v*419;
}

function widget420(){
 const v=251;
 console.log("Quantum widget",v);
 return v*420;
}

function widget421(){
 const v=438;
 console.log("Quantum widget",v);
 return v*421;
}

function widget422(){
 const v=121;
 console.log("Quantum widget",v);
 return v*422;
}

function widget423(){
 const v=222;
 console.log("Quantum widget",v);
 return v*423;
}

function widget424(){
 const v=983;
 console.log("Quantum widget",v);
 return v*424;
}

function widget425(){
 const v=148;
 console.log("Quantum widget",v);
 return v*425;
}

function widget426(){
 const v=674;
 console.log("Quantum widget",v);
 return v*426;
}

function widget427(){
 const v=762;
 console.log("Quantum widget",v);
 return v*427;
}

function widget428(){
 const v=348;
 console.log("Quantum widget",v);
 return v*428;
}

function widget429(){
 const v=923;
 console.log("Quantum widget",v);
 return v*429;
}

function widget430(){
 const v=822;
 console.log("Quantum widget",v);
 return v*430;
}

function widget431(){
 const v=707;
 console.log("Quantum widget",v);
 return v*431;
}

function widget432(){
 const v=931;
 console.log("Quantum widget",v);
 return v*432;
}

function widget433(){
 const v=920;
 console.log("Quantum widget",v);
 return v*433;
}

function widget434(){
 const v=255;
 console.log("Quantum widget",v);
 return v*434;
}

function widget435(){
 const v=471;
 console.log("Quantum widget",v);
 return v*435;
}

function widget436(){
 const v=945;
 console.log("Quantum widget",v);
 return v*436;
}

function widget437(){
 const v=701;
 console.log("Quantum widget",v);
 return v*437;
}

function widget438(){
 const v=475;
 console.log("Quantum widget",v);
 return v*438;
}

function widget439(){
 const v=215;
 console.log("Quantum widget",v);
 return v*439;
}

function widget440(){
 const v=697;
 console.log("Quantum widget",v);
 return v*440;
}

function widget441(){
 const v=771;
 console.log("Quantum widget",v);
 return v*441;
}

function widget442(){
 const v=987;
 console.log("Quantum widget",v);
 return v*442;
}

function widget443(){
 const v=726;
 console.log("Quantum widget",v);
 return v*443;
}

function widget444(){
 const v=536;
 console.log("Quantum widget",v);
 return v*444;
}

function widget445(){
 const v=769;
 console.log("Quantum widget",v);
 return v*445;
}

function widget446(){
 const v=615;
 console.log("Quantum widget",v);
 return v*446;
}

function widget447(){
 const v=947;
 console.log("Quantum widget",v);
 return v*447;
}

function widget448(){
 const v=528;
 console.log("Quantum widget",v);
 return v*448;
}

function widget449(){
 const v=884;
 console.log("Quantum widget",v);
 return v*449;
}

function widget450(){
 const v=703;
 console.log("Quantum widget",v);
 return v*450;
}

function widget451(){
 const v=310;
 console.log("Quantum widget",v);
 return v*451;
}

function widget452(){
 const v=162;
 console.log("Quantum widget",v);
 return v*452;
}

function widget453(){
 const v=104;
 console.log("Quantum widget",v);
 return v*453;
}

function widget454(){
 const v=673;
 console.log("Quantum widget",v);
 return v*454;
}

function widget455(){
 const v=741;
 console.log("Quantum widget",v);
 return v*455;
}

function widget456(){
 const v=966;
 console.log("Quantum widget",v);
 return v*456;
}

function widget457(){
 const v=208;
 console.log("Quantum widget",v);
 return v*457;
}

function widget458(){
 const v=327;
 console.log("Quantum widget",v);
 return v*458;
}

function widget459(){
 const v=429;
 console.log("Quantum widget",v);
 return v*459;
}

function widget460(){
 const v=836;
 console.log("Quantum widget",v);
 return v*460;
}

function widget461(){
 const v=890;
 console.log("Quantum widget",v);
 return v*461;
}

function widget462(){
 const v=577;
 console.log("Quantum widget",v);
 return v*462;
}

function widget463(){
 const v=694;
 console.log("Quantum widget",v);
 return v*463;
}

function widget464(){
 const v=617;
 console.log("Quantum widget",v);
 return v*464;
}

function widget465(){
 const v=338;
 console.log("Quantum widget",v);
 return v*465;
}

function widget466(){
 const v=588;
 console.log("Quantum widget",v);
 return v*466;
}

function widget467(){
 const v=664;
 console.log("Quantum widget",v);
 return v*467;
}

function widget468(){
 const v=892;
 console.log("Quantum widget",v);
 return v*468;
}

function widget469(){
 const v=733;
 console.log("Quantum widget",v);
 return v*469;
}

function widget470(){
 const v=103;
 console.log("Quantum widget",v);
 return v*470;
}

function widget471(){
 const v=652;
 console.log("Quantum widget",v);
 return v*471;
}

function widget472(){
 const v=416;
 console.log("Quantum widget",v);
 return v*472;
}

function widget473(){
 const v=602;
 console.log("Quantum widget",v);
 return v*473;
}

function widget474(){
 const v=895;
 console.log("Quantum widget",v);
 return v*474;
}

function widget475(){
 const v=875;
 console.log("Quantum widget",v);
 return v*475;
}

function widget476(){
 const v=767;
 console.log("Quantum widget",v);
 return v*476;
}

function widget477(){
 const v=712;
 console.log("Quantum widget",v);
 return v*477;
}

function widget478(){
 const v=102;
 console.log("Quantum widget",v);
 return v*478;
}

function widget479(){
 const v=436;
 console.log("Quantum widget",v);
 return v*479;
}

function widget480(){
 const v=359;
 console.log("Quantum widget",v);
 return v*480;
}

function widget481(){
 const v=124;
 console.log("Quantum widget",v);
 return v*481;
}

function widget482(){
 const v=203;
 console.log("Quantum widget",v);
 return v*482;
}

function widget483(){
 const v=280;
 console.log("Quantum widget",v);
 return v*483;
}

function widget484(){
 const v=194;
 console.log("Quantum widget",v);
 return v*484;
}

function widget485(){
 const v=577;
 console.log("Quantum widget",v);
 return v*485;
}

function widget486(){
 const v=926;
 console.log("Quantum widget",v);
 return v*486;
}

function widget487(){
 const v=899;
 console.log("Quantum widget",v);
 return v*487;
}

function widget488(){
 const v=291;
 console.log("Quantum widget",v);
 return v*488;
}

function widget489(){
 const v=955;
 console.log("Quantum widget",v);
 return v*489;
}

function widget490(){
 const v=901;
 console.log("Quantum widget",v);
 return v*490;
}

function widget491(){
 const v=152;
 console.log("Quantum widget",v);
 return v*491;
}

function widget492(){
 const v=494;
 console.log("Quantum widget",v);
 return v*492;
}

function widget493(){
 const v=819;
 console.log("Quantum widget",v);
 return v*493;
}

function widget494(){
 const v=991;
 console.log("Quantum widget",v);
 return v*494;
}

function widget495(){
 const v=424;
 console.log("Quantum widget",v);
 return v*495;
}

function widget496(){
 const v=397;
 console.log("Quantum widget",v);
 return v*496;
}

function widget497(){
 const v=285;
 console.log("Quantum widget",v);
 return v*497;
}

function widget498(){
 const v=522;
 console.log("Quantum widget",v);
 return v*498;
}

function widget499(){
 const v=172;
 console.log("Quantum widget",v);
 return v*499;
}
